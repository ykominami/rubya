# frozen_string_literal: true

class Logger
  VERSION = "1.4.3"
end
