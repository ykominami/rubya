# TODO: Remove in Rake 11

fail "ERROR: 'rake/gempackagetask' is obsolete and no longer supported. " +
  "Use 'rubygems/package_task' instead."
